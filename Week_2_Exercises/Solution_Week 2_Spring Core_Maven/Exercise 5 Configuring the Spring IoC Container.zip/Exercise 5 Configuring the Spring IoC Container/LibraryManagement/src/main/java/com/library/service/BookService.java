package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    // Field to hold the injected BookRepository dependency
    private BookRepository bookRepository;

    // Setter method for BookRepository, used by Spring to inject the dependency
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Method to list books, which calls the findAll method on the injected BookRepository
    public void listBooks() {
        System.out.println("Listing all books...");
        bookRepository.findAll();
    }
}

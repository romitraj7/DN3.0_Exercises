package com.library.repository;

public class BookRepository {
	
	 private BookRepository bookRepository;
	    // Setter method for dependency injection
	    public void setBookRepository(BookRepository bookRepository) {
	        this.bookRepository = bookRepository;
	    }
	public void findAll() {
        System.out.println("Finding all books...");
    }
}

package com.library.repository;

public class BookRepository {
	public void findAll() {
        System.out.println("Finding all books...");
    }
}

package com.library;
import com.library.repository.BookRepository;
import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

// Main Classclass to load the Spring context and test the configuration

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookService = context.getBean("bookService", BookService.class);
        bookService.listBooks();
        BookRepository bookRepository = context.getBean("bookRepository", BookRepository.class);
        bookRepository.findAll();
    }
}

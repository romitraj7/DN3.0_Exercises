package com.library.service;

public class BookService {
	  public void listBooks() {
	        System.out.println("Listing all books...");
	    }
}
